CONTRIBUTING.md placeholder
