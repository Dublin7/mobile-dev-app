# Mobile Dev App

Starter project structure for mobile IDE with terminal support.
